#include "TrayManager.h"
#include "Config.h"
#include <QApplication>
#include <QPixmap>
#include <QDebug>
#include <QCursor>
#include <QGuiApplication>
#include <QScreen>

#ifdef Q_OS_LINUX
#include <QWidget>
#include <QMouseEvent>
#include <QEvent>
#include <QMenu>
#include <QAction>
#endif

TrayManager::TrayManager(QObject* parent)
    : ITrayManager(parent)
    , m_trayIcon(std::make_unique<QSystemTrayIcon>(this))
    , m_animTimer(std::make_unique<QTimer>(this))
{
    connect(m_trayIcon.get(), &QSystemTrayIcon::activated,
            this, &TrayManager::onTrayActivated);
    connect(m_animTimer.get(), &QTimer::timeout,
            this, &TrayManager::onAnimTick);
}

TrayManager::~TrayManager() = default;

void TrayManager::loadIcons() {
    // Загружаем статические иконки из ресурсов
    m_idleIcon = QIcon(Config::TRAY_ICON_IDLE);
    m_activeIcon = QIcon(Config::TRAY_ICON_ACTIVE);
    m_degradedIcon = QIcon(Config::TRAY_ICON_DEGRADED);

    if (m_idleIcon.isNull())
        qWarning() << "TrayManager: не загружена иконка покоя" << Config::TRAY_ICON_IDLE;
    if (m_activeIcon.isNull())
        qWarning() << "TrayManager: не загружена иконка активности" << Config::TRAY_ICON_ACTIVE;
    if (m_degradedIcon.isNull())
        qWarning() << "TrayManager: не загружена иконка degraded" << Config::TRAY_ICON_DEGRADED;

    // Загружаем кадры покадровой анимации
    m_animFrames.clear();
    for (int i = 1; i <= Config::TRAY_ANIM_FRAME_COUNT; ++i) {
        QString path = QString::fromUtf8(Config::TRAY_ANIM_FRAME_PATTERN)
            .arg(i, 2, 10, QChar('0'));
        QIcon frame(path);
        if (frame.isNull()) {
            qWarning() << "TrayManager: не загружен кадр анимации" << path;
        }
        m_animFrames.append(frame);
    }

    if (!m_animFrames.isEmpty())
        qDebug() << "TrayManager: загружено кадров анимации:" << m_animFrames.size();
}

void TrayManager::init() {
    loadIcons();

#ifdef Q_OS_LINUX
    // Gnome Shell (Ubuntu 22.04+) не имеет системного трея.
    // Если AppIndicator не установлен — создаём fallback dock.
    if (!QSystemTrayIcon::isSystemTrayAvailable()) {
        m_fallbackDock = std::make_unique<QWidget>(nullptr,
            Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint | Qt::X11BypassWindowManagerHint);
        m_fallbackDock->setFixedSize(24, 24);
        m_fallbackDock->setAttribute(Qt::WA_ShowWithoutActivating);
        m_fallbackDock->setStyleSheet(
            "QWidget { background: transparent; border-radius: 4px; }"
            "QWidget:hover { background: rgba(255,255,255,30); }");

        // Позиционировать в нижний правый угол
        auto* screen = QGuiApplication::primaryScreen();
        if (screen) {
            auto geom = screen->availableGeometry();
            m_fallbackDock->move(geom.right() - 28, geom.bottom() - 28);
        }

        // При клике — показать меню
        m_fallbackDock->installEventFilter(this);

        m_fallbackDock->show();
        qDebug() << "TrayManager: системный трей недоступен, fallback dock создан";

        // Иконку трея НЕ создаём — анимация не применяется
        m_animTimer->setInterval(Config::TRAY_ANIM_INTERVAL_MS);
        return;
    }
#endif

    // Обычный системный трей (Windows, или Linux с AppIndicator)
    m_trayIcon->setIcon(m_idleIcon);
    QString version = QCoreApplication::applicationVersion();
    m_trayIcon->setToolTip(
        version.isEmpty()
            ? QStringLiteral("GhostWire Desktop")
            : QStringLiteral("GhostWire Desktop v%1").arg(version)
    );

#ifdef Q_OS_LINUX
    // На Linux (особенно в GNOME с AppIndicator) иконка не отображается в верхней панели,
    // если к ней не привязано нативное QMenu. Создаем минимальное меню-заглушку.
    // Левый клик по иконке по-прежнему будет генерировать Trigger (в зависимости от DE),
    // или пользователь сможет открыть дашборд через это меню.
    QMenu* linuxMenu = new QMenu(m_trayIcon.get());
    
    QAction* openAction = linuxMenu->addAction(QStringLiteral("GhostWire Dashboard"));
    connect(openAction, &QAction::triggered, this, [this]() {
        // Передаем пустой QRect для Linux-позиционирования дашборда
        emit iconClicked(QRect());
    });
    
    
    m_trayIcon->setContextMenu(linuxMenu);
#endif

    m_trayIcon->setVisible(true);

    // Таймер покадровой анимации (запускается только при активном режиме)
    m_animTimer->setInterval(Config::TRAY_ANIM_INTERVAL_MS);
}

void TrayManager::cleanup() {
#ifdef Q_OS_LINUX
    if (m_fallbackDock) {
        m_fallbackDock->close();
        m_fallbackDock.reset();
    }
#endif
    if (m_trayIcon) {
        m_trayIcon->setVisible(false);
    }
    m_animTimer->stop();
    m_animFrames.clear();
}

void TrayManager::applyIconState() {
    if (m_state == GHOSTWIRE_PROXY_ONLINE) {
        if (m_hasConnections && !m_animFrames.isEmpty()) {
            if (!m_animTimer->isActive()) {
                m_trayIcon->setIcon(m_animFrames[0]);
                m_animTimer->start();
            }
        } else {
            m_trayIcon->setIcon(m_activeIcon);
            m_animTimer->stop();
        }
    } else if (m_state == GHOSTWIRE_PROXY_DEGRADED) {
        m_trayIcon->setIcon(m_degradedIcon);
        m_animTimer->stop();
    } else {
        m_trayIcon->setIcon(m_idleIcon);
        m_animTimer->stop();
    }
}

QString TrayManager::applyFallbackDockStyle() const {
    if (m_state == GHOSTWIRE_PROXY_ONLINE && m_hasConnections) {
        return "QWidget { background: rgba(76,175,80,60); border: 2px solid #4CAF50; border-radius: 4px; }"
               "QWidget:hover { background: rgba(76,175,80,80); }";
    }
    if (m_state == GHOSTWIRE_PROXY_ONLINE) {
        return "QWidget { background: transparent; border: 2px solid #4CAF50; border-radius: 4px; }"
               "QWidget:hover { background: rgba(76,175,80,40); }";
    }
    if (m_state == GHOSTWIRE_PROXY_DEGRADED) {
        return "QWidget { background: transparent; border: 2px solid #D6A21A; border-radius: 4px; }"
               "QWidget:hover { background: rgba(214,162,26,40); }";
    }
    return "QWidget { background: transparent; border: 2px solid #888; border-radius: 4px; }"
           "QWidget:hover { background: rgba(255,255,255,30); }";
}

void TrayManager::setState(GhostWireProxyState state) {
    const bool stateChanged = (m_state != state);
    m_state = state;
    if (stateChanged) {
        m_animFrameIndex = 0;
    }

    if (m_state != GHOSTWIRE_PROXY_ONLINE) {
        m_hasConnections = false;
    }

#ifdef Q_OS_LINUX
    if (m_fallbackDock) {
        m_fallbackDock->setStyleSheet(applyFallbackDockStyle());
        m_fallbackDock->update();
        return;
    }
#endif

    applyIconState();
}

void TrayManager::setConnectionsState(bool hasConnections) {
    m_hasConnections = (m_state == GHOSTWIRE_PROXY_ONLINE) && hasConnections;

#ifdef Q_OS_LINUX
    if (m_fallbackDock) {
        m_fallbackDock->setStyleSheet(applyFallbackDockStyle());
        m_fallbackDock->update();
        return;
    }
#endif

    applyIconState();
}

void TrayManager::onTrayActivated(QSystemTrayIcon::ActivationReason reason) {
    // Левый и правый клик открывают меню
    if (reason == QSystemTrayIcon::Context || reason == QSystemTrayIcon::Trigger) {
        qDebug() << "TrayManager: tray activated, reason ="
                 << (reason == QSystemTrayIcon::Context ? "Context" : "Trigger");

#ifdef Q_OS_LINUX
        // На Linux QSystemTrayIcon::geometry() всегда пустой.
        // Application определяет позицию через availableGeometry() (Вариант C).
        // Передаём пустой QRect как сигнал использовать panel-based позиционирование.
        emit iconClicked(QRect());
#else
        // Windows: передаём позицию курсора как геометрию иконки
        emit iconClicked(QRect(QCursor::pos(), QSize(1, 1)));
#endif
    }
}

void TrayManager::onAnimTick() {
    if (m_state != GHOSTWIRE_PROXY_ONLINE || !m_hasConnections) return;
    if (m_animFrames.isEmpty()) return;

    int nextFrame = (m_animFrameIndex + 1) % m_animFrames.size();
    if (nextFrame != m_animFrameIndex) {
        m_animFrameIndex = nextFrame;
        m_trayIcon->setIcon(m_animFrames[m_animFrameIndex]);
    }
}

void TrayManager::showMessage(const QString& title, const QString& message,
                              QSystemTrayIcon::MessageIcon icon,
                              int millisecondsTimeout) {
    m_trayIcon->showMessage(title, message, icon, millisecondsTimeout);
}

QRect TrayManager::trayIconGeometry() const {
    return m_trayIcon ? m_trayIcon->geometry() : QRect();
}

bool TrayManager::eventFilter(QObject* watched, QEvent* event) {
#ifdef Q_OS_LINUX
    if (watched == m_fallbackDock && event->type() == QEvent::MouseButtonPress) {
        auto* ev = static_cast<QMouseEvent*>(event);
        if (ev->button() == Qt::LeftButton || ev->button() == Qt::RightButton) {
            emit iconClicked(QRect());
        }
    }
#endif
    return QObject::eventFilter(watched, event);
}
